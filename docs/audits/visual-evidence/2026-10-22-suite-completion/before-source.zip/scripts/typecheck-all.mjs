import { spawnSync } from 'child_process';
import { readdirSync, existsSync } from 'fs';
import { join } from 'path';

const productsDir = join(process.cwd(), 'products');
const subproducts = readdirSync(productsDir).filter((d) =>
  existsSync(join(productsDir, d, 'package.json'))
);

console.log(`\n🚛 Running TypeScript typecheck across ${subproducts.length} sovereign subproducts...\n`);

let failed = false;
for (const sp of subproducts) {
  const pPath = join(productsDir, sp);
  console.log(`\n▶ Typechecking ${sp}...`);
  const res = spawnSync('./node_modules/.bin/tsc', ['--noEmit'], {
    cwd: pPath,
    stdio: 'inherit',
    shell: false,
  });
  if (res.status !== 0) {
    console.error(`❌ Typecheck failure in ${sp}`);
    failed = true;
  } else {
    console.log(`✓ Zero TypeScript errors in ${sp}`);
  }
}

if (failed) {
  console.error('\n❌ One or more subproduct typechecks failed.');
  process.exit(1);
} else {
  console.log('\n✅ All sovereign subproduct typechecks passed with 0 errors!\n');
}
