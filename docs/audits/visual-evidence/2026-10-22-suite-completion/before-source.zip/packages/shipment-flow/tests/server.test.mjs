import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createFlowServer } from '../server.mjs';
import { createShipment } from '../src/domain.mjs';

test('API persists across restart, rejects foreign origins and deduplicates creation', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'trucking-flow-api-')); const file = join(dir, 'store.json');
  let server = await createFlowServer({ file });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  let base = `http://127.0.0.1:${server.address().port}`;
  const post = (path, body, origin = 'http://127.0.0.1:5170') => fetch(base + path, { method: 'POST', headers: { Origin: origin, 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  try {
    assert.equal((await post('/shipments', { reference: 'Origin attack', operationId: 'bad' }, 'https://foreign.example')).status, 403);
    const body = { reference: 'Persistent fixture', operationId: 'create-fixture-1' };
    const created = await (await post('/shipments', body)).json();
    const retry = await (await post('/shipments', body)).json();
    assert.equal(retry.id, created.id);
    assert.equal((await post('/shipments', { ...body, reference: 'Different content' })).status, 409);
    assert.equal((await fetch(base + '/shipments').then(r => r.json())).length, 1);
    const amend = { type: 'amend', productId: 'command-center-portal', operationId: 'amend-fixture-1', expectedRevision: created.revision, payload: { input: { ...created.input, loadedMiles: 110 } } };
    const a = await (await post(`/shipments/${created.id}/commands`, amend)).json();
    const b = await (await post(`/shipments/${created.id}/commands`, amend)).json();
    assert.equal(a.revision, 2); assert.equal(b.revision, 2);
    assert.equal((await post(`/shipments/${created.id}/commands`, { ...amend, operationId: 'stale-writer' })).status, 409);
    await new Promise(resolve => server.close(resolve));
    server = await createFlowServer({ file }); await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
    base = `http://127.0.0.1:${server.address().port}`;
    const restored = await fetch(base + `/shipments/${created.id}`).then(r => r.json());
    assert.equal(restored.input.loadedMiles, 110); assert.equal(restored.revision, 2);
    const writeA = { ...amend, operationId: 'concurrent-a', expectedRevision: 2, payload: { input: { ...restored.input, loadedMiles: 111 } } };
    const writeB = { ...amend, operationId: 'concurrent-b', expectedRevision: 2, payload: { input: { ...restored.input, loadedMiles: 112 } } };
    const concurrent = await Promise.all([post(`/shipments/${created.id}/commands`, writeA), post(`/shipments/${created.id}/commands`, writeB)]);
    assert.deepEqual(concurrent.map(r => r.status).sort(), [200, 409]);
    assert.equal(JSON.parse(await readFile(file, 'utf8')).shipments.length, 1);
  } finally { await new Promise(resolve => server.close(resolve)); }
});

test('delivered warehouse stock remains held while departed origin doors become available', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'trucking-flow-resources-')); const file = join(dir, 'store.json');
  const s = createShipment('Resource custody fixture'); s.status = 'delivered';
  s.results.warehouse = { ok: true, inputRevision: s.inputRevision, details: { assignments: [{ slotId: 'BIN-HELD' }] } };
  s.results.yard = { ok: true, inputRevision: s.inputRevision, details: { doorId: 'DOOR-RELEASED' } };
  await writeFile(file, JSON.stringify({ schemaVersion: 1, shipments: [s] }));
  const server = await createFlowServer({ file }); await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  try {
    const usage = await fetch(`http://127.0.0.1:${server.address().port}/resources`).then(r => r.json());
    assert.deepEqual(usage.warehouseSlotIds, ['BIN-HELD']); assert.deepEqual(usage.yardDoorIds, []);
  } finally { await new Promise(resolve => server.close(resolve)); }
});

test('an unreadable or incompatible store is preserved instead of silently reset', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'trucking-flow-corrupt-')); const file = join(dir, 'store.json');
  await writeFile(file, '{corrupt-record');
  await assert.rejects(createFlowServer({ file }));
  assert.equal(await readFile(file, 'utf8'), '{corrupt-record');
});

test('a saved receiving operation can be retried after upstream invalidation without replaying its reservation', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'trucking-flow-retry-')); const file = join(dir, 'store.json');
  const server = await createFlowServer({ file }); await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  const post = (path, body) => fetch(base + path, { method: 'POST', headers: { Origin: 'http://127.0.0.1:5170', 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  try {
    let s = await (await post('/shipments', { reference: 'Historical retry', operationId: 'retry-create' })).json();
    const send = async (stage, details) => {
      const productId = { asset: 'product-04-asset-studio', fit: 'product-01-cargo-fit', warehouse: 'product-06-warehouse-space-flow' }[stage];
      const command = { type: 'evaluate', productId, operationId: `retry-${stage}-${s.revision}`, expectedRevision: s.revision, payload: { stage, result: { ok: true, summary: 'API retry fixture', details } } };
      const response = await post(`/shipments/${s.id}/commands`, command); assert.equal(response.status, 200); s = await response.json(); return command;
    };
    const asset = { equipmentId: s.input.equipmentId, lengthIn: 630, widthIn: 100, heightIn: 100, doorWidthIn: 96, doorHeightIn: 98, payloadLbs: 45000 };
    await send('asset', asset);
    await send('fit', { geometryFeasible: true, violations: 0, unitIds: s.input.units.map(u => u.id), placements: s.input.units.map(u => ({ unitId: u.id })) });
    const receiving = await send('warehouse', { assignments: s.input.units.map((u, i) => ({ unitId: u.id, barcode: u.barcode, slotId: `S-${i}`, slotCode: `R-${i}` })) });
    await send('asset', asset); assert.equal(s.results.warehouse, undefined);
    const before = await readFile(file, 'utf8');
    const retry = await post(`/shipments/${s.id}/commands`, receiving); assert.equal(retry.status, 200);
    const retried = await retry.json(); assert.equal(retried.revision, s.revision); assert.equal(retried.results.warehouse, undefined);
    assert.equal(await readFile(file, 'utf8'), before);
  } finally { await new Promise(resolve => server.close(resolve)); }
});
