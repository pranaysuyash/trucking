import React from 'react';
import { FraudRiskIndicators, OperatingAuthorityStatus } from '../engine/types';

interface FraudRiskRadarProps {
  fraud: FraudRiskIndicators;
  authority: OperatingAuthorityStatus;
  powerUnits: number;
  drivers: number;
}

export const FraudRiskRadar: React.FC<FraudRiskRadarProps> = ({
  fraud,
  authority,
  powerUnits,
  drivers,
}) => {
  const isHighRisk =
    fraud.doubleBrokeringRisk === 'high' ||
    fraud.chameleonCarrierRisk === 'high' ||
    authority !== 'AUTHORIZED_FOR_HIRE';

  return (
    <div className="safety-card fraud-card">
      <div className="card-header">
        <div className="title-with-subtitle">
          <h3>️ Fraud Risk & Double-Brokering Detection Radar</h3>
          <span className="subtitle">Chameleon Carrier & Unauthorized Re-Brokering Shield</span>
        </div>
        <span className={`risk-badge ${isHighRisk ? 'critical' : 'clean'}`}>
          {isHighRisk ? ' HIGH FRAUD RISK' : ' LOW FRAUD PROFILE'}
        </span>
      </div>

      <div className="fraud-indicators-grid">
        <div className={`fraud-box ${fraud.doubleBrokeringRisk}`}>
          <span className="fb-lbl">DOUBLE-BROKERING RISK</span>
          <strong className="fb-val">{fraud.doubleBrokeringRisk.toUpperCase()}</strong>
          <span className="fb-sub">IP & Dispatch Nexus Analysis</span>
        </div>

        <div className={`fraud-box ${fraud.chameleonCarrierRisk}`}>
          <span className="fb-lbl">CHAMELEON ENTITY RISK</span>
          <strong className="fb-val">{fraud.chameleonCarrierRisk.toUpperCase()}</strong>
          <span className="fb-sub">Re-Incarnated MC History</span>
        </div>

        <div className="fraud-box">
          <span className="fb-lbl">FREIGHTGUARD REPORTS</span>
          <strong className="fb-val" style={{ color: fraud.freightGuardReportsCount > 0 ? '#ef4444' : '#10b981' }}>
            {fraud.freightGuardReportsCount} Reports
          </strong>
          <span className="fb-sub">Industry Blacklist Claims</span>
        </div>

        <div className="fraud-box">
          <span className="fb-lbl">OPERATING AUTHORITY</span>
          <strong className="fb-val" style={{ color: authority === 'AUTHORIZED_FOR_HIRE' ? '#10b981' : '#ef4444' }}>
            {authority.replace(/_/g, ' ')}
          </strong>
          <span className="fb-sub">{powerUnits} Trucks · {drivers} Drivers</span>
        </div>
      </div>

      {isHighRisk && (
        <div className="fraud-alert-banner">
          ️ <strong>AUTOMATED FRAUD LOCKOUT ACTIVE:</strong> Carrier exhibits severe fraud or double-brokering indicators. Dispatch system has engaged the Do-Not-Dispatch (DND) hard lockout.
        </div>
      )}
    </div>
  );
};
