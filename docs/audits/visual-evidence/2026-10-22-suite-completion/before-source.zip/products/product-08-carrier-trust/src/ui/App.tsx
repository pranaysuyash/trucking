import { useState, useMemo } from 'react';
import { INITIAL_CARRIERS } from '../engine/carriers';
import { CarrierProfile } from '../engine/types';
import {
  buildPricingSafetyBridgeUrl,
  buildHosSafetyBridgeUrl,
  buildCommandCenterSafetyBridgeUrl,
} from '../engine/bridges';
import { CarrierScoreDial } from './CarrierScoreDial';
import { BasicPercentilesGrid } from './BasicPercentilesGrid';
import { CoiVerificationCard } from './CoiVerificationCard';
import { FraudRiskRadar } from './FraudRiskRadar';
import { SuiteDock } from './SuiteDock';
import { useShipmentContext } from '../suite/useShipmentContext';

export function App() {
  const [carriers] = useState<CarrierProfile[]>(INITIAL_CARRIERS);
  const [selectedDot, setSelectedDot] = useState<string>(INITIAL_CARRIERS[0].dotNumber);
  const [searchQuery, setSearchQuery] = useState<string>('');
  useShipmentContext(shipment => setSelectedDot(shipment.input.carrierDot));

  const activeCarrier = useMemo(() => {
    return carriers.find((c) => c.dotNumber === selectedDot) || carriers[0];
  }, [carriers, selectedDot]);

  const filteredCarriers = useMemo(() => {
    if (!searchQuery.trim()) return carriers;
    const q = searchQuery.toLowerCase();
    return carriers.filter(
      (c) =>
        c.legalName.toLowerCase().includes(q) ||
        c.dotNumber.includes(q) ||
        c.mcNumber.includes(q)
    );
  }, [carriers, searchQuery]);

  const p02Url = buildPricingSafetyBridgeUrl(activeCarrier);
  const p03Url = buildHosSafetyBridgeUrl(activeCarrier);
  const portalUrl = buildCommandCenterSafetyBridgeUrl(activeCarrier);

  return (
    <div className="safety-app-root">
      <a href="#main-content" className="skip-link">Skip to main content</a>
      <SuiteDock currentProductId="product-08-carrier-trust" />
      <p style={{ padding: '12px 20px' }}>Scenario carrier review: authority, insurance and risk fields below are seeded examples evaluated against customer policy. They are not live verification or independent fraud findings.</p>

      {/* Main Header */}
      <header className="safety-top-nav">
        <div className="nav-title-group">
          <span className="platform-tag">TRUCKING PLATFORM</span>
          <h1 className="brand-title">Product 08 — Carrier Trust & Anti-Fraud Shield</h1>
        </div>

        <nav aria-label="Platform Bridges" className="nav-bridges">
          <a href="http://localhost:5170" className="nav-link" target="_blank" rel="noopener noreferrer">
            <span className="dot dot-portal" /> Command Center (5170)
          </a>
          <a href="http://localhost:5174" className="nav-link" target="_blank" rel="noopener noreferrer">
            <span className="dot dot-p02" /> P02 Pricing (5174)
          </a>
          <a href="http://localhost:5175" className="nav-link" target="_blank" rel="noopener noreferrer">
            <span className="dot dot-p03" /> P03 HOS (5175)
          </a>
          <a href="http://localhost:5180" className="nav-link active" target="_blank" rel="noopener noreferrer">
            <span className="dot dot-p06" /> P08 Carrier Trust (5180)
          </a>
        </nav>
      </header>

      {/* Content Wrap */}
      <main id="main-content" className="safety-content-wrap" tabIndex={-1}>
        {/* Carrier Search & Selector Bar */}
        <div className="carrier-selector-bar">
          <div className="selector-left">
            <span className="bar-label">CARRIER PROFILE:</span>
            <div className="carrier-pills">
              {filteredCarriers.map((c) => (
                <button
                  key={c.dotNumber}
                  className={`btn-carrier-pill ${c.dotNumber === activeCarrier.dotNumber ? 'active' : ''}`}
                  onClick={() => setSelectedDot(c.dotNumber)}
                >
                  <span className="pill-name">{c.legalName}</span>
                  <span className="pill-dot">DOT #{c.dotNumber}</span>
                  <span className={`pill-status-dot ${c.dispatchEligibility}`} />
                </button>
              ))}
            </div>
          </div>

          <div className="selector-right">
            <input
              type="text"
              placeholder="Search DOT #, MC #, or Name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="carrier-search-input"
            />
          </div>
        </div>

        {/* Carrier Details & Identity Banner */}
        <div className="carrier-identity-banner">
          <div className="id-col main-info">
            <span className="col-label">LEGAL CARRIER ENTITY</span>
            <h2 className="entity-name">{activeCarrier.legalName}</h2>
            <div className="entity-ids">
              <span>USDOT: <strong>{activeCarrier.dotNumber}</strong></span>
              <span>MC / FF: <strong>{activeCarrier.mcNumber}</strong></span>
              <span>MCS-150: {activeCarrier.mcs150Date}</span>
            </div>
            <div className="entity-address">
              {activeCarrier.physicalAddress}, {activeCarrier.city}, {activeCarrier.state} {activeCarrier.zip}
            </div>
          </div>

          <div className="id-col fleet-info">
            <span className="col-label">EQUIPMENT & FLEET SIZE</span>
            <div className="fleet-stat-row">
              <div>Power Units: <strong>{activeCarrier.powerUnitCount}</strong></div>
              <div>CDL Drivers: <strong>{activeCarrier.driverCount}</strong></div>
            </div>
            <div style={{ marginTop: '8px' }}>
              Operating Authority: <strong style={{ color: activeCarrier.operatingAuthority === 'AUTHORIZED_FOR_HIRE' ? '#10b981' : '#ef4444' }}>{activeCarrier.operatingAuthority}</strong>
            </div>
          </div>

          <div className="id-col cross-bridges">
            <span className="col-label">DISPATCH GATES & CROSS BRIDGES</span>
            <div className="bridge-btn-group">
              <a href={portalUrl} target="_blank" rel="noopener noreferrer" className="btn-cross portal">
                Orchestrate in Portal (5170) ↗
              </a>
              <a href={p02Url} target="_blank" rel="noopener noreferrer" className="btn-cross p02">
                Lock Rate in Pricing (5174) ↗
              </a>
              <a href={p03Url} target="_blank" rel="noopener noreferrer" className="btn-cross p03">
                Audit Driver HOS (5175) ↗
              </a>
            </div>
          </div>
        </div>

        {/* Audit Blockers or Warnings Banner */}
        {activeCarrier.blockers.length > 0 && (
          <div className="audit-banner blockers">
            <strong> DO NOT DISPATCH (DND) LOCKOUT ACTIVE:</strong>
            <ul>
              {activeCarrier.blockers.map((b, i) => (
                <li key={i}>{b}</li>
              ))}
            </ul>
          </div>
        )}

        {activeCarrier.warnings.length > 0 && activeCarrier.blockers.length === 0 && (
          <div className="audit-banner warnings">
            <strong>️ CONDITIONAL DISPATCH WARNINGS (Requires Safety Director Sign-Off):</strong>
            <ul>
              {activeCarrier.warnings.map((w, i) => (
                <li key={i}>{w}</li>
              ))}
            </ul>
          </div>
        )}

        {/* Primary Safety HUD Grid */}
        <div className="safety-grid">
          {/* Composite Safety Dial */}
          <CarrierScoreDial
            score={activeCarrier.compositeSafetyScore}
            eligibility={activeCarrier.dispatchEligibility}
            safetyRating={activeCarrier.safetyRating}
          />

          {/* Certificate of Insurance (COI) */}
          <CoiVerificationCard policies={activeCarrier.insurancePolicies} />

          {/* SMS BASIC Percentiles */}
          <BasicPercentilesGrid basics={activeCarrier.basics} />

          {/* Fraud & Double Brokering Radar */}
          <FraudRiskRadar
            fraud={activeCarrier.fraudIndicators}
            authority={activeCarrier.operatingAuthority}
            powerUnits={activeCarrier.powerUnitCount}
            drivers={activeCarrier.driverCount}
          />
        </div>
      </main>
    </div>
  );
}
