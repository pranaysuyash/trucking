import { INITIAL_CARRIERS } from './carriers';
import { auditCarrierCompliance, getDaysUntilExpiration } from './scoring';
import type { ShipmentAdapter } from '../suite/types';

export const shipmentAdapter: ShipmentAdapter = {
  stage: 'carrier',
  evaluate(shipment) {
    const carrier = INITIAL_CARRIERS.find(c => c.dotNumber === shipment.input.carrierDot);
    if (!carrier) throw new Error('Carrier is absent from the explicit scenario roster. Unknown does not mean approved.');
    const audit = auditCarrierCompliance({ ...carrier, insurancePolicies: carrier.insurancePolicies.map(p => ({ ...p, daysUntilExpiration: getDaysUntilExpiration(p.expirationDate) })) });
    return {
      ok: audit.dispatchEligibility === 'APPROVED', summary: `${carrier.legalName}: ${audit.dispatchEligibility} under configured customer policy, using seeded scenario evidence. ${[...audit.blockers, ...audit.warnings].join(' ')}`,
      details: { dotNumber: carrier.dotNumber, eligibility: audit.dispatchEligibility, evidenceSource: 'seeded_scenario', expiresAt: new Date(Date.now() + 15 * 60 * 1000).toISOString(), blockers: audit.blockers, warnings: audit.warnings },
    };
  },
};
