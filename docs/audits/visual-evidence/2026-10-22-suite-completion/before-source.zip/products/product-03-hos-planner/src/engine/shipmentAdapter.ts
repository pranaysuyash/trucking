import { planCorridorItinerary } from './corridor';
import type { ShipmentAdapter } from '../suite/types';

export const shipmentAdapter: ShipmentAdapter = {
  stage: 'hos',
  evaluate(shipment) {
    if (shipment.input.priorRestHours < 10) throw new Error('This scenario requires a declared ten-hour full rest. Split rest and live ELD history are not supported.');
    const plan = planCorridorItinerary({ origin: shipment.input.origin, destination: shipment.input.destination, distanceMiles: shipment.input.loadedMiles, avgSpeedMph: 55, driverMode: 'solo', initialDrivingHoursRemaining: 11, initialShiftHoursRemaining: 14 });
    return {
      ok: plan.isLegal, summary: `${plan.totalTransitHours.toFixed(1)} modeled transit hours for ${shipment.input.driverId}. Full-rest scenario only; no live ELD or appointment guarantee.`,
      details: { driverId: shipment.input.driverId, priorRestHours: shipment.input.priorRestHours, ruleScope: 'full_rest_only', isLegal: plan.isLegal, totalTransitHours: plan.totalTransitHours, waypoints: plan.waypoints, violations: plan.violations },
    };
  },
};
