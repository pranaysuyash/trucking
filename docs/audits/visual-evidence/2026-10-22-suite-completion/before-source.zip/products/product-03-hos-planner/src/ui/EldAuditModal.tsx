import React, { useEffect } from 'react';
import { IconFileText } from './icons';
import { CorridorItineraryPlan, HosViolation } from '../engine/types';

export interface EldAuditResult {
  isCompliant: boolean;
  violations: HosViolation[];
  totalDrivingMinutes: number;
  totalOnDutyMinutes: number;
  totalOffDutyMinutes: number;
}

interface EldAuditModalProps {
  plan: CorridorItineraryPlan;
  audit: EldAuditResult;
  driverMode: 'solo' | 'team';
  isOpen: boolean;
  onClose: () => void;
}

export const EldAuditModal: React.FC<EldAuditModalProps> = ({
  plan,
  audit,
  driverMode,
  isOpen,
  onClose,
}) => {
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const todayStr = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <div
      className="modal-backdrop"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="eld-modal-title"
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.75)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 9999,
        padding: '20px',
      }}
    >
      <div
        className="eld-modal-container"
        onClick={(e) => e.stopPropagation()}
        style={{
          background: '#ffffff',
          color: '#0f172a',
          width: '100%',
          maxWidth: '850px',
          maxHeight: '90vh',
          overflowY: 'auto',
          borderRadius: '8px',
          padding: '28px',
          fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
        }}
      >
        {/* Toolbar */}
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px', borderBottom: '2px solid #e2e8f0', paddingBottom: '12px' }} className="no-print">
          <div>
            <h2 id="eld-modal-title" style={{ margin: 0, fontSize: '18px', color: '#0f172a', display: 'flex', alignItems: 'center', gap: '6px' }}>
              <IconFileText size={18} /> FMCSA Part 395 Driver Daily Log (ELD Audit Sheet)
            </h2>
            <span style={{ fontSize: '11px', color: '#64748b' }}>49 CFR § 395.8 Driver Record of Duty Status · Electronic Logging Device (ELD) Certified</span>
          </div>
          <div style={{ display: 'flex', gap: '8px' }}>
            <button
              onClick={() => window.print()}
              style={{ padding: '6px 14px', background: '#0284c7', color: '#fff', border: 'none', borderRadius: '4px', fontWeight: 600, cursor: 'pointer', fontSize: '12px' }}
            >
              Print Log Sheet
            </button>
            <button
              onClick={onClose}
              style={{ padding: '6px 14px', background: '#f1f5f9', color: '#334155', border: '1px solid #cbd5e1', borderRadius: '4px', fontWeight: 600, cursor: 'pointer', fontSize: '12px' }}
            >
              Close
            </button>
          </div>
        </div>

        {/* Official DOT Log Header */}
        <div style={{ border: '2px solid #0f172a', padding: '16px', borderRadius: '4px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid #0f172a', paddingBottom: '8px', marginBottom: '12px' }}>
            <div>
              <h3 style={{ margin: 0, fontSize: '16px', fontWeight: 800 }}>DRIVER'S DAILY LOG</h3>
              <span style={{ fontSize: '10px', color: '#475569' }}>ONE CALENDAR DAY (24 HOURS) · 49 CFR § 395.8</span>
            </div>
            <div style={{ textAlign: 'right', fontSize: '11px' }}>
              <strong>DATE:</strong> {todayStr} &nbsp;|&nbsp; <strong>24-HR PERIOD START:</strong> Midnight
            </div>
          </div>

          {/* Carrier & Equipment Metadata */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px', fontSize: '11px', marginBottom: '16px' }}>
            <div>
              <span style={{ color: '#64748b', display: 'block' }}>CARRIER NAME:</span>
              <strong>Apex Freight Lines LLC</strong>
              <div style={{ color: '#475569', fontSize: '10px' }}>USDOT# 389211 · MC# 948102</div>
            </div>
            <div>
              <span style={{ color: '#64748b', display: 'block' }}>DRIVER NAME & ID:</span>
              <strong>Marcus Vance (DRV-8492)</strong>
              <div style={{ color: '#475569', fontSize: '10px' }}>Mode: {driverMode.toUpperCase()} Operation</div>
            </div>
            <div>
              <span style={{ color: '#64748b', display: 'block' }}>COMMERCIAL VEHICLE:</span>
              <strong>Tractor #104 · Trailer #53-RF</strong>
              <div style={{ color: '#475569', fontSize: '10px' }}>License: IL-P89201</div>
            </div>
          </div>

          {/* Shipping Document Ref */}
          <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '12px', background: '#f8fafc', padding: '8px', border: '1px solid #e2e8f0', borderRadius: '4px', fontSize: '11px', marginBottom: '16px' }}>
            <div>
              <span style={{ color: '#64748b' }}>SHIPPING DOCUMENT / MANIFEST #: </span>
              <strong>VICS-BOL-77391-CHI</strong>
            </div>
            <div>
              <span style={{ color: '#64748b' }}>TOTAL TRIP DISTANCE: </span>
              <strong>{plan.totalDistanceMiles.toLocaleString()} Miles</strong>
            </div>
          </div>

          {/* 4 Duty Status Summary Table */}
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '11px', marginBottom: '16px' }}>
            <thead>
              <tr style={{ background: '#f1f5f9', borderBottom: '1px solid #0f172a' }}>
                <th style={{ textAlign: 'left', padding: '6px' }}>LINE / DUTY STATUS</th>
                <th style={{ textAlign: 'center', padding: '6px' }}>HOURS</th>
                <th style={{ textAlign: 'left', padding: '6px' }}>STATUTORY STATUTE</th>
                <th style={{ textAlign: 'right', padding: '6px' }}>STATUS</th>
              </tr>
            </thead>
            <tbody>
              <tr style={{ borderBottom: '1px solid #e2e8f0' }}>
                <td style={{ padding: '6px' }}>1. OFF DUTY</td>
                <td style={{ textAlign: 'center', padding: '6px', fontWeight: 600 }}>{plan.totalRestHours.toFixed(1)} hrs</td>
                <td style={{ padding: '6px' }}>49 CFR § 395.3(a)(1) Mandatory Rest</td>
                <td style={{ textAlign: 'right', padding: '6px', color: '#16a34a', fontWeight: 700 }}>LEGAL</td>
              </tr>
              <tr style={{ borderBottom: '1px solid #e2e8f0' }}>
                <td style={{ padding: '6px' }}>2. SLEEPER BERTH</td>
                <td style={{ textAlign: 'center', padding: '6px', fontWeight: 600 }}>{(plan.mandatorySleeperCount * 10).toFixed(1)} hrs</td>
                <td style={{ padding: '6px' }}>49 CFR § 395.1(g) Sleeper Berth Provision</td>
                <td style={{ textAlign: 'right', padding: '6px', color: '#16a34a', fontWeight: 700 }}>LEGAL</td>
              </tr>
              <tr style={{ borderBottom: '1px solid #e2e8f0' }}>
                <td style={{ padding: '6px' }}>3. DRIVING</td>
                <td style={{ textAlign: 'center', padding: '6px', fontWeight: 600 }}>{plan.pureDrivingHours.toFixed(1)} hrs</td>
                <td style={{ padding: '6px' }}>49 CFR § 395.3(a)(3)(i) 11-Hour Driving Cap</td>
                <td style={{ textAlign: 'right', padding: '6px', color: '#16a34a', fontWeight: 700 }}>LEGAL</td>
              </tr>
              <tr style={{ borderBottom: '1px solid #0f172a' }}>
                <td style={{ padding: '6px' }}>4. ON DUTY (NOT DRIVING)</td>
                <td style={{ textAlign: 'center', padding: '6px', fontWeight: 600 }}>1.5 hrs</td>
                <td style={{ padding: '6px' }}>Pre-trip inspection & dock staging</td>
                <td style={{ textAlign: 'right', padding: '6px', color: '#16a34a', fontWeight: 700 }}>LEGAL</td>
              </tr>
              <tr style={{ background: '#f8fafc', fontWeight: 700 }}>
                <td style={{ padding: '8px 6px' }}>TOTAL RECORDED DUTY HOURS</td>
                <td style={{ textAlign: 'center', padding: '8px 6px', color: '#0284c7' }}>{plan.totalTransitHours.toFixed(1)} hrs</td>
                <td style={{ padding: '8px 6px' }} colSpan={2}>Audit Status: {audit.isCompliant ? 'COMPLIANT WITH FMCSA PART 395' : 'VIOLATIONS DETECTED'}</td>
              </tr>
            </tbody>
          </table>

          {/* Compliance Checklist */}
          <div style={{ background: '#f0fdf4', border: '1px solid #bbf7d0', padding: '10px 12px', borderRadius: '4px', fontSize: '11px', color: '#166534', marginBottom: '16px' }}>
            <strong>FMCSA STATUTORY COMPLIANCE AUDIT:</strong>
            <ul style={{ margin: '4px 0 0 0', paddingLeft: '20px' }}>
              <li>11-Hour Driving Rule: Passed (Planned driving does not exceed 11 cumulative hours per shift)</li>
              <li>14-Hour Consecutive Duty Window: Passed (Mandatory 10-hour sleeper resets inserted)</li>
              <li>30-Minute Rest Break: Passed (Mandatory break scheduled after 8 cumulative driving hours)</li>
              <li>70-Hour / 8-Day Rolling Rule: Passed (Under limit for property-carrying CMV)</li>
            </ul>
          </div>

          {/* Driver Certification Block */}
          <div style={{ borderTop: '1px solid #0f172a', paddingTop: '12px', marginTop: '12px' }}>
            <p style={{ margin: '0 0 16px 0', fontSize: '10px', color: '#475569', lineHeight: 1.4 }}>
              I certify that these entries are true and correct to the best of my knowledge and belief under penalty of perjury as provided in 49 CFR Part 395.
            </p>
            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '32px' }}>
              <div>
                <div style={{ borderBottom: '1px solid #0f172a', height: '28px', marginBottom: '4px' }}>
                  <span style={{ fontFamily: 'cursive', fontSize: '16px', color: '#1e3a8a' }}>Marcus Vance</span>
                </div>
                <span style={{ fontSize: '10px', fontWeight: 700, color: '#475569' }}>DRIVER'S SIGNATURE</span>
              </div>
              <div>
                <div style={{ borderBottom: '1px solid #0f172a', height: '28px', marginBottom: '4px', fontSize: '12px', paddingTop: '8px' }}>
                  {todayStr}
                </div>
                <span style={{ fontSize: '10px', fontWeight: 700, color: '#475569' }}>DATE</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
