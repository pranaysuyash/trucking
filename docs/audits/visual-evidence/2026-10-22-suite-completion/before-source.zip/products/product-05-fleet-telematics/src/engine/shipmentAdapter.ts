import type { ShipmentAdapter } from '../suite/types';
// Connected departure/arrival are explicit scenario events; standalone sensor
// simulation stays independent and is never substituted for observed GPS.
export const shipmentAdapter: ShipmentAdapter = {};
