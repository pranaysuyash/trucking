import { getVehicleCatalog } from './catalog';
import type { ShipmentAdapter } from '../suite/types';

export const shipmentAdapter: ShipmentAdapter = {
  stage: 'asset',
  evaluate(shipment) {
    const vehicle = getVehicleCatalog().find(v => v.id === shipment.input.equipmentId);
    if (!vehicle) throw new Error('Selected equipment is not present in this product catalog.');
    return {
      ok: true, summary: `${vehicle.name}: declared interior, door and payload snapshot ready.`,
      details: {
        equipmentId: vehicle.id, name: vehicle.name,
        lengthIn: vehicle.interior.lengthFt * 12, widthIn: vehicle.interior.widthFt * 12, heightIn: vehicle.interior.heightFt * 12,
        doorWidthIn: vehicle.interior.doorWidthFt * 12, doorHeightIn: vehicle.interior.doorHeightFt * 12,
        payloadLbs: vehicle.weight.maxPayloadLbs, loadedMpg: vehicle.fuelEnergy.loadedMpg,
        source: 'Catalog scenario template; actual equipment measurement remains separate',
      },
    };
  },
};
