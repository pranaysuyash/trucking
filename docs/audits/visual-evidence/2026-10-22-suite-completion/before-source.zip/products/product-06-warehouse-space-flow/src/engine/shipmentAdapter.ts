import { translateCargoFitLoadToInboundManifest } from './cargoFitBridge';
import { createCanonicalFacility, findSlotById, getAllSlots } from './spatialModel';
import { solvePutawayManifest } from './putawayEngine';
import { executeScanVerification } from './verificationEngine';
import type { Shipment, ShipmentAdapter } from '../suite/types';

export function inboundForShipment(shipment: Shipment) {
  return translateCargoFitLoadToInboundManifest({
    loadId: shipment.id, vehicleType: shipment.input.equipmentId, carrier: shipment.input.carrierDot, trailerNumber: shipment.input.trailerId,
    destinationFacilityId: 'LOCAL-RECEIVING-01', totalWeightLbs: shipment.input.units.reduce((sum, u) => sum + u.weightLbs, 0),
    packedItems: shipment.input.units.map(u => ({ ...u, itemId: u.id })),
  });
}

export const shipmentAdapter: ShipmentAdapter = {
  stage: 'warehouse',
  evaluate(shipment, resources) {
    if (!shipment.results.fit?.ok || shipment.results.fit.inputRevision !== shipment.inputRevision) throw new Error('Publish the current Cargo Fit result before reserving receiving space.');
    const manifest = inboundForShipment(shipment);
    const facility = createCanonicalFacility();
    getAllSlots(facility).forEach(slot => { if (resources.warehouseSlotIds.includes(slot.id)) slot.status = 'blocked'; });
    const result = solvePutawayManifest(facility, manifest);
    return {
      ok: result.conflictCount === 0, summary: `${result.totalExpected - result.conflictCount}/${result.totalExpected} identified units have compatible receiving locations.`,
      details: { facilityId: 'LOCAL-RECEIVING-01', assignments: result.recommendations.filter(r => r.targetSlotId).map(r => ({ unitId: r.palletId, barcode: r.barcode, slotId: r.targetSlotId, slotCode: r.targetLocationCode })), recommendations: result.recommendations },
    };
  },
  verifyReceipt(shipment, receipt) {
    const records = shipment.results.warehouse?.details.recommendations as ReturnType<typeof solvePutawayManifest>['recommendations'] | undefined;
    if (!records || !receipt.receiver.trim()) throw new Error('A receiver and the approved receiving plan are required.');
    const facility = createCanonicalFacility();
    for (const scan of receipt.units) {
      const recommendation = records.find(r => r.palletId === scan.id);
      if (!recommendation || scan.barcode !== recommendation.barcode) throw new Error('Handling-unit barcode does not match the shipment.');
      const slot = findSlotById(facility, recommendation.targetSlotId!);
      if (!slot || slot.status !== 'available') throw new Error('Receiving location is no longer available.');
      slot.status = 'reserved_inbound'; slot.reservedPalletId = scan.id;
      const result = executeScanVerification(facility, recommendation, scan.slotCode, receipt.receiver);
      if (!result.success) throw new Error(result.message);
    }
  },
};
