import { INITIAL_DOCK_DOORS, INITIAL_YARD_SPOTS, processGateCheckIn } from './yardEngine';
import type { ShipmentAdapter } from '../suite/types';

export const shipmentAdapter: ShipmentAdapter = {
  stage: 'yard',
  evaluate(shipment, resources) {
    if (!shipment.results.warehouse?.ok || shipment.results.warehouse.inputRevision !== shipment.inputRevision) throw new Error('Reserve current receiving locations in Warehouse first.');
    const type = shipment.input.units.some(u => u.temperatureClass !== 'ambient') ? 'REEFER' : 'DRY_VAN';
    const { allocatedDoor } = processGateCheckIn(
      shipment.id, shipment.input.driverId, 'SCENARIO', shipment.input.tractorId, shipment.input.trailerId,
      shipment.input.carrierDot, 'SCENARIO-SEAL', false, type, INITIAL_DOCK_DOORS.map(d => resources.yardDoorIds.includes(d.doorId) ? { ...d, status: 'OCCUPIED' } : d), INITIAL_YARD_SPOTS,
    );
    return {
      ok: Boolean(allocatedDoor), summary: allocatedDoor ? `Compatible scenario dock ${allocatedDoor.doorNumber} allocated to ${shipment.input.trailerId}. Seal verification remains an execution task.` : 'No compatible dock available; dispatch stays blocked.',
      details: { doorId: allocatedDoor?.doorId, trailerId: shipment.input.trailerId, available: Boolean(allocatedDoor), facilityId: 'LOCAL-ORIGIN-01' },
    };
  },
};
