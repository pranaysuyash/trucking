import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { shipmentAdapter } from '../engine/shipmentAdapter';
import products from './productRegistry.json';
import { STAGE_LABELS, type FlowResources, type FlowStage, type ReceiptInput, type Shipment } from './types';
import './shipment.css';

const API = 'http://127.0.0.1:5171';
const isLocal = ['localhost', '127.0.0.1'].includes(window.location.hostname);
interface Command { type: string; operationId: string; expectedRevision: number; productId: string; payload: Record<string, unknown> }
async function request<T>(path: string, body?: unknown): Promise<T> {
  const response = await fetch(`${API}${path}`, {
    method: body ? 'POST' : 'GET', headers: body ? { 'Content-Type': 'application/json' } : {},
    body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(8000),
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error ?? `Shipment request failed (${response.status})`);
  return data as T;
}

export function ShipmentWorkspace({ productId }: { productId: string }) {
  const [shipmentId, setShipmentId] = useState(() => new URLSearchParams(window.location.search).get('shipment') ?? '');
  const [shipment, setShipment] = useState<Shipment | null>(null);
  const [expanded, setExpanded] = useState(Boolean(shipmentId) || productId === 'command-center-portal');
  const [list, setList] = useState<{ id: string; reference: string; status: string }[]>([]);
  const [reference, setReference] = useState('Regional distribution scenario');
  const [message, setMessage] = useState('');
  const [connection, setConnection] = useState('Standalone tools available below');
  const [clock, setClock] = useState(Date.now());
  const [busy, setBusy] = useState(false);
  const [pending, setPending] = useState<Command | null>(null);
  const [receiver, setReceiver] = useState('');
  const [scans, setScans] = useState<Record<string, { barcode: string; slotCode: string }>>({});
  const [resolution, setResolution] = useState('');
  const [weight, setWeight] = useState('');
  const [resources, setResources] = useState<FlowResources>({ warehouseSlotIds: [], yardDoorIds: [] });
  const creationAttempt = useRef({ reference: '', operationId: '' });
  const portal = productId === 'command-center-portal';
  useEffect(() => {
    if (shipment) window.dispatchEvent(new CustomEvent('trucking:shipment-context', { detail: shipment }));
  }, [shipment]);
  const stage = shipmentAdapter.stage;
  const preview = useMemo(() => {
    if (!shipment || !shipmentAdapter.evaluate) return null;
    try { return shipmentAdapter.evaluate(shipment, resources); }
    catch (error) { return { ok: false, summary: error instanceof Error ? error.message : 'Evaluation unavailable', details: {} }; }
  }, [shipment, resources]);

  const select = (id: string) => {
    setShipmentId(id); setShipment(null); setPending(null); setMessage(''); setScans({});
    const url = new URL(window.location.href);
    if (id) url.searchParams.set('shipment', id); else url.searchParams.delete('shipment');
    window.history.replaceState(null, '', url);
  };
  const refresh = useCallback(async () => {
    if (!shipmentId || !isLocal) return;
    const next = await request<Shipment>(`/shipments/${shipmentId}`);
    setShipment(next); setConnection('Connected to local scenario service');
  }, [shipmentId]);
  useEffect(() => {
    if (!expanded || !isLocal) return;
    let active = true;
    const poll = async () => {
      if (active) setClock(Date.now());
      try {
        if (shipmentId) {
          const [next, usage] = await Promise.all([request<Shipment>(`/shipments/${shipmentId}`), request<FlowResources>(`/resources?exclude=${shipmentId}`)]);
          if (active) { setShipment(prev => prev?.revision === next.revision ? prev : next); setResources(prev => JSON.stringify(prev) === JSON.stringify(usage) ? prev : usage); setConnection('Connected to local scenario service'); }
        } else {
          const next = await request<typeof list>('/shipments');
          if (active) { setList(next); setConnection('Local scenario service available'); }
        }
      } catch { if (active) setConnection('Local service unavailable. Standalone tools remain available below.'); }
    };
    void poll(); const timer = window.setInterval(poll, 2000);
    return () => { active = false; window.clearInterval(timer); };
  }, [expanded, shipmentId]);

  async function run(command: Command) {
    setBusy(true); setMessage(''); setPending(command);
    try {
      const next = await request<Shipment>(`/shipments/${shipmentId}/commands`, command);
      setShipment(next); setPending(null); setMessage('Saved to the shared shipment history.');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Operation failed.');
      await refresh().catch(() => {});
    } finally { setBusy(false); }
  }
  function act(type: string, payload: Record<string, unknown> = {}) {
    if (!shipment || busy || pending) return;
    void run({ type, payload, operationId: crypto.randomUUID(), expectedRevision: shipment.revision, productId });
  }
  const blockers = shipment ? (Object.keys(STAGE_LABELS) as FlowStage[]).filter(key => {
    const result = shipment.results[key]; return !result?.ok || result.inputRevision !== shipment.inputRevision;
  }).map(key => STAGE_LABELS[key]) : [];
  if (shipment?.exceptions.some(e => !e.resolved)) blockers.push('Open exception');
  if (shipment?.results.carrier?.details.expiresAt && Date.parse(String(shipment.results.carrier.details.expiresAt)) <= clock) blockers.push('Carrier decision expired');
  const assignments = (shipment?.results.warehouse?.details.assignments ?? []) as { unitId: string; slotCode: string; barcode: string }[];
  const disabled = busy || Boolean(pending);

  return <section className="shipment-workspace" aria-label="Connected shipment workspace">
    <details open={expanded} onToggle={e => setExpanded(e.currentTarget.open)}>
      <summary>Connected shipment workspace <span>{shipment ? `${shipment.reference} · ${shipment.status.replaceAll('_', ' ')}` : 'optional'}</span></summary>
      <div className="shipment-body">
        <p className="shipment-mode">LOCAL SCENARIO · {connection}. Carrier, duty, motion and receipt evidence here are explicitly simulated or manually entered. These actions do not book freight or issue payments.</p>
        {!isLocal ? <p>Shared local scenarios are available on the loopback previews. This product remains usable independently below.</p> : <>
          {!shipmentId && <div className="shipment-actions">
            <label>Existing shipment <select aria-label="Choose shipment" value="" onChange={e => select(e.target.value)}><option value="">Choose a saved scenario</option>{list.map(s => <option key={s.id} value={s.id}>{s.reference} · {s.status}</option>)}</select></label>
            {portal && <><label>Scenario reference <input aria-label="Scenario reference" value={reference} onChange={e => setReference(e.target.value)} /></label><button disabled={busy} onClick={async () => {
              setBusy(true);
              if (creationAttempt.current.reference !== reference) creationAttempt.current = { reference, operationId: crypto.randomUUID() };
              try { const next = await request<Shipment>('/shipments', creationAttempt.current); select(next.id); setShipment(next); creationAttempt.current = { reference: '', operationId: '' }; }
              catch (error) { setMessage(error instanceof Error ? error.message : 'Creation failed.'); }
              finally { setBusy(false); }
            }}>Create local shipment</button></>}
          </div>}
          {shipmentId && <div className="shipment-actions"><button onClick={() => void refresh().catch(e => setMessage(e.message))}>Refresh shipment</button><button onClick={() => select('')}>Use standalone tools</button></div>}
          {shipment && <>
            <p className="shipment-identity"><strong>{shipment.reference}</strong> · Shipment {shipment.id} · Record revision {shipment.revision} · Input revision {shipment.inputRevision}</p>
            <p>{shipment.input.origin} → {shipment.input.destination} · {shipment.input.loadedMiles} loaded mi · {shipment.input.units.reduce((n, u) => n + u.weightLbs, 0).toLocaleString()} lb · {shipment.input.units.length} identified handling units</p>
            <p className="shipment-mode">The tools below import this shipment snapshot for inspection. Local exploratory edits stay local; publish decisions against the shared manifest above, and amend that manifest in Command Center when required.</p>
            <nav className="shipment-products" aria-label="Shipment products">{products.map(p => {
              const url = new URL(p.routes.dev); url.hostname = window.location.hostname; url.searchParams.set('shipment', shipment.id);
              return <a key={p.id} aria-current={p.id === productId ? 'page' : undefined} href={url.toString()}>{p.code} {p.shortName}</a>;
            })}</nav>
            <ul className="shipment-stages">{(Object.keys(STAGE_LABELS) as FlowStage[]).map(key => {
              const result = shipment.results[key]; const status = !result ? 'Pending' : result.inputRevision !== shipment.inputRevision ? 'Stale' : result.ok ? 'Recorded' : 'Rejected';
              return <li key={key} data-stage={key}><strong>{STAGE_LABELS[key]}</strong><span>{status}</span>{result && <small>{result.summary}</small>}</li>;
            })}</ul>
            <details><summary>Handling units and assigned locations</summary><div className="shipment-table-wrap"><table><thead><tr><th>Handling unit</th><th>Barcode</th><th>Mass</th><th>Receiving slot</th></tr></thead><tbody>{shipment.input.units.map(u => <tr key={u.id}><td>{u.description}<small>{u.id}</small></td><td>{u.barcode}</td><td>{u.weightLbs} lb</td><td>{assignments.find(a => a.unitId === u.id)?.slotCode ?? 'Unassigned'}</td></tr>)}</tbody></table></div></details>
            {stage && preview && <div className="shipment-decision"><strong>{STAGE_LABELS[stage]} evaluation</strong><p>{preview.summary}</p>{stage === 'quote' && Array.isArray(preview.details.lines) && <table><thead><tr><th>Accepted term</th><th>USD</th></tr></thead><tbody>{(preview.details.lines as { label: string; cents: number }[]).map(line => <tr key={line.label}><td>{line.label}</td><td>{(line.cents / 100).toFixed(2)}</td></tr>)}</tbody></table>}<button disabled={disabled || shipment.status !== 'draft'} onClick={() => act('evaluate', { stage, result: preview })}>{stage === 'quote' ? 'Accept scenario quote' : 'Publish shipment evaluation'}</button></div>}
            {portal && <>
              <p data-testid="dispatch-blockers">{blockers.length ? `Dispatch prerequisites: ${blockers.join(', ')}` : 'All current planning prerequisites recorded.'}</p>
              <button disabled={disabled || shipment.status !== 'draft' || blockers.length > 0} onClick={() => act('dispatch')}>Approve scenario dispatch</button>
              {shipment.status === 'draft' && <details><summary>Amend shipment manifest</summary><p>Changing inputs retains earlier decisions as stale. Re-evaluate affected products before dispatch.</p><label>First unit weight (lb) <input aria-label="First unit weight (lb)" type="number" value={weight} placeholder={String(shipment.input.units[0].weightLbs)} onChange={e => setWeight(e.target.value)} /></label><button disabled={disabled || !weight} onClick={() => act('amend', { input: { ...shipment.input, units: shipment.input.units.map((u, i) => i === 0 ? { ...u, weightLbs: Number(weight) } : u) } })}>Save manifest amendment</button></details>}
              {shipment.status === 'delivered' && <button disabled={disabled || shipment.exceptions.some(e => !e.resolved)} onClick={() => act('invoice', { totalCents: shipment.results.quote?.details.totalCents })}>Prepare reconciled invoice</button>}
              {shipment.invoice && <div className="shipment-invoice"><strong>Invoice ready for export</strong><p>{shipment.invoice.currency} {(shipment.invoice.totalCents / 100).toFixed(2)} · Matched to accepted scenario quote and receipt. No payment issued.</p><button onClick={() => {
                const url = URL.createObjectURL(new Blob([JSON.stringify(shipment, null, 2)], { type: 'application/json' })); const a = document.createElement('a'); a.href = url; a.download = `${shipment.id}-invoice-evidence.json`; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
              }}>Export invoice evidence JSON</button></div>}
            </>}
            {productId === 'product-05-fleet-telematics' && <div className="shipment-actions"><button disabled={disabled || shipment.status !== 'dispatched'} onClick={() => act('depart', { tractorId: shipment.input.tractorId })}>Record scenario departure</button><button disabled={disabled || shipment.status !== 'in_transit'} onClick={() => act('arrive', { tractorId: shipment.input.tractorId })}>Record scenario arrival</button><button disabled={disabled || shipment.status === 'invoice_ready'} onClick={() => act('exception.open', { message: 'Scenario receiving delay requires review.' })}>Record scenario delay exception</button></div>}
            {productId === 'product-06-warehouse-space-flow' && shipment.status === 'arrived' && <form onSubmit={e => {
              e.preventDefault(); const receipt: ReceiptInput = { receiver, units: shipment.input.units.map(u => ({ id: u.id, barcode: scans[u.id]?.barcode ?? '', slotCode: scans[u.id]?.slotCode ?? '' })) };
              try { shipmentAdapter.verifyReceipt?.(shipment, receipt); act('deliver', receipt as unknown as Record<string, unknown>); }
              catch (error) { setMessage(error instanceof Error ? error.message : 'Receipt validation failed.'); }
            }}><h3>Confirm scenario receiving</h3><p>Enter each barcode and reserved location independently. This is manual scenario evidence.</p><label>Receiver name <input required aria-label="Receiver name" value={receiver} onChange={e => setReceiver(e.target.value)} /></label>{shipment.input.units.map(u => <fieldset key={u.id}><legend>{u.description}</legend><label>Barcode <input required aria-label={`Barcode ${u.id}`} value={scans[u.id]?.barcode ?? ''} onChange={e => setScans(prev => ({ ...prev, [u.id]: { slotCode: prev[u.id]?.slotCode ?? '', barcode: e.target.value } }))} /></label><label>Location <input required aria-label={`Location ${u.id}`} value={scans[u.id]?.slotCode ?? ''} onChange={e => setScans(prev => ({ ...prev, [u.id]: { barcode: prev[u.id]?.barcode ?? '', slotCode: e.target.value } }))} /></label></fieldset>)}<button disabled={disabled} type="submit">Confirm received handling units</button></form>}
            {shipment.exceptions.length > 0 && <div className="shipment-exceptions"><h3>Shipment exceptions</h3>{shipment.exceptions.map(ex => <p key={ex.id}>{ex.message} · {ex.resolved ? `Resolved: ${ex.resolution}` : 'Open'}{portal && !ex.resolved && <><input aria-label="Exception resolution" value={resolution} onChange={e => setResolution(e.target.value)} placeholder="Describe the recovery decision" /><button disabled={disabled || !resolution.trim()} onClick={() => act('exception.resolve', { id: ex.id, resolution })}>Resolve exception</button></>}</p>)}</div>}
            <details><summary>Shipment history ({shipment.events.length} events)</summary><ol className="shipment-history">{[...shipment.events].reverse().map(e => <li key={e.id}><strong>{e.type}</strong> · {e.productId} · {e.at}<p>{e.note}</p></li>)}</ol></details>
          </>}
          {message && <p role="status" className="shipment-message">{message}</p>}
          {pending && !busy && <div className="shipment-actions"><button onClick={() => void run(pending)}>Retry same operation</button><button onClick={() => { setPending(null); setMessage('Pending attempt dismissed. Review refreshed state before a new action.'); }}>Dismiss pending attempt</button></div>}
        </>}
      </div>
    </details>
  </section>;
}
