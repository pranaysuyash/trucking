import { useEffect, useRef } from 'react';
import type { Shipment } from './types';

/** Imports a shared snapshot once per relevant revision, preserving local edits. */
export function useShipmentContext(apply: (shipment: Shipment) => void, execution = false): void {
  const callback = useRef(apply); callback.current = apply;
  const last = useRef('');
  useEffect(() => {
    const receive = (event: Event) => {
      const s = (event as CustomEvent<Shipment>).detail;
      if (!s || new URLSearchParams(window.location.search).get('shipment') !== s.id) return;
      const key = `${s.id}:${s.inputRevision}:${s.results.asset?.recordedAt ?? ''}:${execution ? `${s.results.warehouse?.recordedAt ?? ''}:${s.delivery?.receivedAt ?? ''}` : ''}`;
      if (key === last.current) return;
      callback.current(s); last.current = key;
    };
    window.addEventListener('trucking:shipment-context', receive);
    return () => window.removeEventListener('trucking:shipment-context', receive);
  }, [execution]);
}
