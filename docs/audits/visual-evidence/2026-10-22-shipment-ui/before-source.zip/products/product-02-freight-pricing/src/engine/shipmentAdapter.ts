import { generateRateQuote } from './quote';
import { EIA_DIESEL_BENCHMARK } from './dieselBenchmark';
import { evaluateDynamicAccessorials } from './accessorialRateCard';
import { evaluateBrokerMargin } from './brokerMargin';
import type { CarrierCostProfile } from './types';
import type { Shipment, ShipmentAdapter } from '../suite/types';

export function profileForShipment(shipment: Shipment): CarrierCostProfile {
  return {
    id: 'local-scenario', name: 'Declared scenario cost profile', annualMilesBenchmark: 100000, truckPaymentMonthly: 2100, trailerPaymentMonthly: 750,
    insuranceMonthly: 1250, permitsLicensesMonthly: 200, dispatchSoftwareMonthly: 350, driverCpm: 0.68, maintenanceTiresCpm: 0.22, tollsTotal: 0, miscellaneousCpm: 0.05,
    avgMpgLoaded: Number(shipment.results.asset?.details.loadedMpg) || 6.5, avgMpgEmpty: 7.5, currentDieselPricePerGallon: EIA_DIESEL_BENCHMARK.pricePerGallon, fscPegBasePricePerGallon: 1.2,
  };
}

export const shipmentAdapter: ShipmentAdapter = {
  stage: 'quote',
  evaluate(shipment) {
    if (!shipment.results.fit?.ok || shipment.results.fit.inputRevision !== shipment.inputRevision) throw new Error('Publish the current loading plan before accepting a quote.');
    const profile = profileForShipment(shipment);
    const [originCity, originState = 'IL'] = shipment.input.origin.split(','); const [destCity, destState = 'WI'] = shipment.input.destination.split(',');
    const quote = generateRateQuote({ originCity, originState: originState.trim(), destCity, destState: destState.trim(), loadedMiles: shipment.input.loadedMiles, deadheadMiles: shipment.input.deadheadMiles, equipmentCategory: shipment.input.equipmentId.includes('reefer') ? 'reefer' : 'dry_van' }, profile,
      { detentionHours: 0, layoverDays: 0, lumperFee: 0, extraStopsCount: 0, isHazmat: false, requiresTarp: false, reeferContinuousTempControl: false });
    const accessorials = evaluateDynamicAccessorials({ totalDwellHours: 0 });
    const lines = [{ label: 'Linehaul', cents: Math.round(quote.recommendedLinehaulRate * 100) }, { label: 'Fuel surcharge', cents: Math.round(quote.totalFuelSurcharge * 100) }, { label: 'Approved scenario accessorials', cents: Math.round(accessorials.totalAmount * 100) }];
    const totalCents = lines.reduce((sum, l) => sum + l.cents, 0);
    const margin = evaluateBrokerMargin({ shipperSellRate: totalCents / 100, carrierBuyRate: totalCents / 100, approvedAccessorialsBilled: 0, approvedAccessorialsPaid: 0 });
    return { ok: true, summary: `USD ${(totalCents / 100).toFixed(2)} carrier estimate using declared costs and dated diesel input. Publishing accepts these terms for this local scenario only.`, details: { currency: 'USD', lines, totalCents, accepted: true, profile, dieselObservedOn: EIA_DIESEL_BENCHMARK.observedOn, scenarioMargin: margin } };
  },
};
