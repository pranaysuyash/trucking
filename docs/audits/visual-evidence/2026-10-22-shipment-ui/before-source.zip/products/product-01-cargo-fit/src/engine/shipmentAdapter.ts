import { analyzeScenario, DEFAULT_SETTINGS } from './scenario';
import type { EquipmentProfile, Scenario } from './types';
import type { Shipment, ShipmentAdapter } from '../suite/types';

export function scenarioForShipment(shipment: Shipment): Scenario {
    const asset = shipment.results.asset;
    if (!asset?.ok || asset.inputRevision !== shipment.inputRevision) throw new Error('Publish the current equipment snapshot in Asset Studio first.');
    const d = asset.details;
    const equipment: EquipmentProfile = {
      id: shipment.input.equipmentId, name: String(d.name), length: Number(d.lengthIn), width: Number(d.widthIn), height: Number(d.heightIn), unit: 'in',
      doorWidth: Number(d.doorWidthIn), doorHeight: Number(d.doorHeightIn), payload: Number(d.payloadLbs), massUnit: 'lb', cost: null, currency: 'USD', costSource: 'none', source: String(d.source), included: true,
    };
    const scenario: Scenario = {
      name: shipment.reference, equipment: [equipment], settings: { ...DEFAULT_SETTINGS, maxMs: 2000 },
      rows: shipment.input.units.map(u => ({ uid: u.id, label: u.description, qty: 1, length: u.lengthIn, width: u.widthIn, height: u.heightIn, dimUnit: 'in', weight: u.weightLbs, weightUnit: 'lb', rotation: 'upright', stackable: u.stackable, stop: 1 })),
    };
    return scenario;
}
export const shipmentAdapter: ShipmentAdapter = {
  stage: 'fit',
  evaluate(shipment) {
    const result = analyzeScenario(scenarioForShipment(shipment)).results[0];
    const placements = result.arrangements[result.best]?.placements ?? [];
    const ok = result.geometryFeasible && result.violations.length === 0 && placements.length === shipment.input.units.length;
    return {
      ok, summary: `${placements.length}/${shipment.input.units.length} handling units placed. ${ok ? 'Independent geometric checks passed under declared constraints.' : result.reasons.map(r => r.message).join(' ')}`,
      details: { geometryFeasible: ok, violations: result.violations.length, unitIds: placements.map(p => p.rowUid), placements, status: result.status, solverVersion: result.solver.version, checks: result.checks, limitation: 'No physical scale, restraint or road-legal certification.' },
    };
  },
};
